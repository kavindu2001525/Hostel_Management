<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hostel Management System</title>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
</head>
<body>
<!-- Background Video -->
<video autoplay muted loop id="bg-video">
<source src="bg.mp4" type="video/mp4">

    Your browser does not support HTML5 video.
</video>
<div class="overlay"></div>
<div class="container">
<h1>🏠 Hostel Management System</h1>
<p>Select your role to continue</p>
<div class="login-cards">
<div class="card student">
<div class="content">
<h2>Student</h2>
<a href="pages/login.php?role=student" class="btn">Login</a>
</div>
</div>
<div class="card warden">
<div class="content">
<h2>Warden</h2>
<a href="pages/warden_login.php" class="btn">Login</button></a>
</div>
</div>
<div class="card admin">
<div class="content">
<h2>Admin</h2>
<a href="pages/admin_login.php" class="btn">Login</button></a>
</div>
</div>
</div>
</div>
<a href="pages/signup.php?role=admin" class="btn-small">Sign Up</a>
</body>
</html>


 