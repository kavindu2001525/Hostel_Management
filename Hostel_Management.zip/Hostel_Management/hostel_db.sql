-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 29, 2025 at 05:19 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

CREATE TABLE `Admin` (
  `Admin_ID` varchar(10) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Admin`
--

INSERT INTO `Admin` (`Admin_ID`, `First_Name`, `Last_Name`, `Email`, `password`) VALUES
('A001', 'Nimal', 'Perera', 'admin2@hostel.lk', 'a123');

-- --------------------------------------------------------

--
-- Table structure for table `Complaint`
--

CREATE TABLE `Complaint` (
  `Complaint_ID` int(11) NOT NULL,
  `Student_ID` varchar(10) DEFAULT NULL,
  `Complaint_Type` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Office_Description` text DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `Warden_ID` varchar(10) DEFAULT NULL,
  `Admin_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Complaint`
--

INSERT INTO `Complaint` (`Complaint_ID`, `Student_ID`, `Complaint_Type`, `Description`, `Office_Description`, `Date`, `Status`, `Warden_ID`, `Admin_ID`) VALUES
(3, '2022E128', 'Room Issue', 'sdsds', NULL, '2025-06-27', 'Pending', NULL, NULL),
(4, '2022E128', 'Water Supply', 'no water\r\ni am in the toilat', NULL, '2025-06-27', 'Pending', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Payment`
--

CREATE TABLE `Payment` (
  `Payment_ID` varchar(10) NOT NULL,
  `Student_ID` varchar(10) DEFAULT NULL,
  `Monthly_Rent` int(11) DEFAULT NULL,
  `Payment_Day` date DEFAULT NULL,
  `Next_Pay_Day` date DEFAULT NULL,
  `Penalty_for_Late` int(11) DEFAULT NULL,
  `Admin_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Room`
--

CREATE TABLE `Room` (
  `Room_Number` varchar(10) NOT NULL,
  `Room_Type` varchar(20) DEFAULT NULL,
  `AC_Type` varchar(20) DEFAULT NULL,
  `Capacity` int(11) DEFAULT NULL,
  `Occupied_Count` int(11) DEFAULT NULL,
  `Admin_ID` varchar(10) DEFAULT NULL,
  `Warden_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Room`
--

INSERT INTO `Room` (`Room_Number`, `Room_Type`, `AC_Type`, `Capacity`, `Occupied_Count`, `Admin_ID`, `Warden_ID`) VALUES
('R101', 'Single', 'AC', 1, 1, NULL, NULL),
('R102', 'Double', 'Non-AC', 2, NULL, NULL, NULL),
('R103', 'Triple', 'AC', 3, NULL, NULL, NULL),
('R104', 'Double', 'AC', 2, NULL, NULL, NULL),
('R105', 'Single', 'Non-AC', 1, NULL, NULL, NULL),
('R106', 'Triple', 'Non-AC', 3, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Room_Request`
--

CREATE TABLE `Room_Request` (
  `Request_ID` int(11) NOT NULL,
  `Student_ID` varchar(10) DEFAULT NULL,
  `Room_Number` varchar(10) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Room_Request`
--

INSERT INTO `Room_Request` (`Request_ID`, `Student_ID`, `Room_Number`, `Status`) VALUES
(1, '2022E128', 'R101', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `Student`
--

CREATE TABLE `Student` (
  `Student_ID` varchar(10) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Room_Number` varchar(10) DEFAULT NULL,
  `Duration_of_Stay` varchar(20) DEFAULT NULL,
  `Checkin_Date` date DEFAULT NULL,
  `Checkout_Date` date DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `Admin_ID` varchar(10) DEFAULT NULL,
  `Warden_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Student`
--

INSERT INTO `Student` (`Student_ID`, `First_Name`, `Last_Name`, `Email`, `Room_Number`, `Duration_of_Stay`, `Checkin_Date`, `Checkout_Date`, `password`, `Admin_ID`, `Warden_ID`) VALUES
('2022E125', 'thisara', 'supun', 'thisara@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('2022E128', 'kavindu', 'rathnayake', 'kavindulaksith10@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Student_ID` varchar(10) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Student_ID`, `First_Name`, `Last_Name`, `Email`, `password`) VALUES
('2022E125', 'thisara', 'supun', 'thisara@gmail.com', '$2y$10$n.pWm2M9DX5HK6X4hbwa6.UytF0bhjiHbO/9k8MkkaDEaPjlOBmcu'),
('2022E128', 'kavindu', 'rathnayake', 'kavindulaksith10@gmail.com', '$2y$10$s6YGv42QdQbNjVwdXo4eueHMbO43iUvoIMHOLF0KscN0EHH64Ci86');

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `insert_student_after_user` AFTER INSERT ON `user` FOR EACH ROW BEGIN

  INSERT INTO Student (Student_ID, First_Name, Last_Name, Email)

  VALUES (NEW.Student_ID, NEW.First_Name, NEW.Last_Name, NEW.Email);

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `Visitor_Log`
--

CREATE TABLE `Visitor_Log` (
  `Visitor_ID` varchar(10) NOT NULL,
  `Student_ID` varchar(10) DEFAULT NULL,
  `Visit_Date` date DEFAULT NULL,
  `Visit_Time` time DEFAULT NULL,
  `Reason` text DEFAULT NULL,
  `Warden_ID` varchar(10) DEFAULT NULL,
  `Admin_ID` varchar(10) DEFAULT NULL,
  `Warden_Approval_Status` varchar(20) DEFAULT 'Pending',
  `Warden_Disapproval_Reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Visitor_Log`
--

INSERT INTO `Visitor_Log` (`Visitor_ID`, `Student_ID`, `Visit_Date`, `Visit_Time`, `Reason`, `Warden_ID`, `Admin_ID`, `Warden_Approval_Status`, `Warden_Disapproval_Reason`) VALUES
('V4099', '2022E128', '2025-06-30', '08:09:00', 'jhiui', NULL, NULL, 'Pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Warden`
--

CREATE TABLE `Warden` (
  `Warden_ID` varchar(10) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Admin_ID` varchar(10) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Warden`
--

INSERT INTO `Warden` (`Warden_ID`, `First_Name`, `Last_Name`, `Email`, `Admin_ID`, `password`) VALUES
('W001', 'Sunil', 'Bandara', 'sunil@hostel.lk', NULL, 'w123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Admin`
--
ALTER TABLE `Admin`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `Complaint`
--
ALTER TABLE `Complaint`
  ADD PRIMARY KEY (`Complaint_ID`),
  ADD KEY `Student_ID` (`Student_ID`),
  ADD KEY `Warden_ID` (`Warden_ID`),
  ADD KEY `Admin_ID` (`Admin_ID`);

--
-- Indexes for table `Payment`
--
ALTER TABLE `Payment`
  ADD PRIMARY KEY (`Payment_ID`),
  ADD KEY `Student_ID` (`Student_ID`),
  ADD KEY `Admin_ID` (`Admin_ID`);

--
-- Indexes for table `Room`
--
ALTER TABLE `Room`
  ADD PRIMARY KEY (`Room_Number`),
  ADD KEY `Admin_ID` (`Admin_ID`),
  ADD KEY `Warden_ID` (`Warden_ID`);

--
-- Indexes for table `Room_Request`
--
ALTER TABLE `Room_Request`
  ADD PRIMARY KEY (`Request_ID`),
  ADD KEY `Student_ID` (`Student_ID`),
  ADD KEY `Room_Number` (`Room_Number`);

--
-- Indexes for table `Student`
--
ALTER TABLE `Student`
  ADD PRIMARY KEY (`Student_ID`),
  ADD KEY `Room_Number` (`Room_Number`),
  ADD KEY `Admin_ID` (`Admin_ID`),
  ADD KEY `Warden_ID` (`Warden_ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Student_ID`);

--
-- Indexes for table `Visitor_Log`
--
ALTER TABLE `Visitor_Log`
  ADD PRIMARY KEY (`Visitor_ID`),
  ADD KEY `Warden_ID` (`Warden_ID`),
  ADD KEY `Student_ID` (`Student_ID`);

--
-- Indexes for table `Warden`
--
ALTER TABLE `Warden`
  ADD PRIMARY KEY (`Warden_ID`),
  ADD KEY `Admin_ID` (`Admin_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Complaint`
--
ALTER TABLE `Complaint`
  MODIFY `Complaint_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Room_Request`
--
ALTER TABLE `Room_Request`
  MODIFY `Request_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Complaint`
--
ALTER TABLE `Complaint`
  ADD CONSTRAINT `complaint_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `Student` (`Student_ID`),
  ADD CONSTRAINT `complaint_ibfk_2` FOREIGN KEY (`Warden_ID`) REFERENCES `Warden` (`Warden_ID`),
  ADD CONSTRAINT `complaint_ibfk_3` FOREIGN KEY (`Admin_ID`) REFERENCES `Admin` (`Admin_ID`);

--
-- Constraints for table `Payment`
--
ALTER TABLE `Payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `Student` (`Student_ID`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`Admin_ID`) REFERENCES `Admin` (`Admin_ID`);

--
-- Constraints for table `Room`
--
ALTER TABLE `Room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`Admin_ID`) REFERENCES `Admin` (`Admin_ID`),
  ADD CONSTRAINT `room_ibfk_2` FOREIGN KEY (`Warden_ID`) REFERENCES `Warden` (`Warden_ID`);

--
-- Constraints for table `Room_Request`
--
ALTER TABLE `Room_Request`
  ADD CONSTRAINT `room_request_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `Student` (`Student_ID`),
  ADD CONSTRAINT `room_request_ibfk_2` FOREIGN KEY (`Room_Number`) REFERENCES `Room` (`Room_Number`);

--
-- Constraints for table `Student`
--
ALTER TABLE `Student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Room_Number`) REFERENCES `Room` (`Room_Number`),
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`Admin_ID`) REFERENCES `Admin` (`Admin_ID`),
  ADD CONSTRAINT `student_ibfk_3` FOREIGN KEY (`Warden_ID`) REFERENCES `Warden` (`Warden_ID`);

--
-- Constraints for table `Visitor_Log`
--
ALTER TABLE `Visitor_Log`
  ADD CONSTRAINT `visitor_log_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `Student` (`Student_ID`),
  ADD CONSTRAINT `visitor_log_ibfk_2` FOREIGN KEY (`Warden_ID`) REFERENCES `Warden` (`Warden_ID`),
  ADD CONSTRAINT `visitor_log_ibfk_3` FOREIGN KEY (`Student_ID`) REFERENCES `Student` (`Student_ID`);

--
-- Constraints for table `Warden`
--
ALTER TABLE `Warden`
  ADD CONSTRAINT `warden_ibfk_1` FOREIGN KEY (`Admin_ID`) REFERENCES `Admin` (`Admin_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
