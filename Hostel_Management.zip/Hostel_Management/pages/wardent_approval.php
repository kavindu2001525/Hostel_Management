<?php

session_start();

include('db_connect.php'); // Your database connection file

// Assuming student ID is stored in session

$studentID = $_SESSION['student_id'];

?>
<!DOCTYPE html>
<html>
<head>
<title>Warden Approval Status</title>
<style>

        body {

            font-family: Arial, sans-serif;

            background-color: #eef;

            padding: 20px;

        }

        table {

            border-collapse: collapse;

            width: 90%;

            margin: 20px auto;

            background-color: #fff;

        }

        th, td {

            padding: 10px;

            text-align: center;

            border: 1px solid #ccc;

        }

        h2, h3 {

            text-align: center;

            margin-top: 30px;

        }

        .status-pending {

            color: orange;

            font-weight: bold;

        }

        .status-accepted {

            color: green;

            font-weight: bold;

        }

        .status-rejected {

            color: red;

            font-weight: bold;

        }
</style>
</head>
<body>
<h2>Warden Approval Status</h2>
<!-- Room Request Section -->
<h3>Room Request Status</h3>
<table>
<tr>
<th>Room Number</th>
<th>Status</th>
</tr>
<?php

    $roomQuery = mysqli_query($conn, "SELECT * FROM Room_Request WHERE Student_ID = '$studentID'");

    if (mysqli_num_rows($roomQuery) > 0) {

        while ($row = mysqli_fetch_assoc($roomQuery)) {

            $status = $row['Status'];

            $statusClass = '';

            if ($status == 'Pending') $statusClass = 'status-pending';

            elseif ($status == 'Accepted') $statusClass = 'status-accepted';

            elseif ($status == 'Rejected') $statusClass = 'status-rejected';

            echo "<tr>
<td>{$row['Room_Number']}</td>
<td class='$statusClass'>{$status}</td>
</tr>";

        }

    } else {

        echo "<tr><td colspan='2'>No room request found.</td></tr>";

    }

    ?>
</table>
<!-- Late Pass Section -->
<h3>Late Pass / Visitor Request Status</h3>
<table>
<tr>
<th>Visit Date</th>
<th>Visit Time</th>
<th>Reason</th>
<th>Warden Status</th>
<th>Disapproval Reason</th>
</tr>
<?php

    $visitorQuery = mysqli_query($conn, "SELECT * FROM Visitor_Log WHERE Student_ID = '$studentID'");

    if (mysqli_num_rows($visitorQuery) > 0) {

        while ($row = mysqli_fetch_assoc($visitorQuery)) {

            $status = $row['Warden_Approval_Status'];

            $statusClass = '';

            if ($status == 'Pending') $statusClass = 'status-pending';

            elseif ($status == 'Accepted') $statusClass = 'status-accepted';

            elseif ($status == 'Rejected') $statusClass = 'status-rejected';

            echo "<tr>
<td>{$row['Visit_Date']}</td>
<td>{$row['Visit_Time']}</td>
<td>{$row['Reason']}</td>
<td class='$statusClass'>{$status}</td>
<td>{$row['Warden_Disapproval_Reason']}</td>
</tr>";

        }

    } else {

        echo "<tr><td colspan='5'>No visitor or late pass request found.</td></tr>";

    }

    ?>
</table>
</body>
</html>
 