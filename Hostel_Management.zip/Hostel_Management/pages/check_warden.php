<?php

session_start();

$host = "localhost";

$user = "root";

$pass = "";

$db   = "hostel_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {

  die("Connection failed: " . $conn->connect_error);

}

$warden_id = $_POST['warden_id'] ?? '';

$password = $_POST['password'] ?? '';

if (empty($warden_id) || empty($password)) {

  $_SESSION['login_error'] = "Please fill both fields.";

  header("Location: warden_login.php");

  exit;

}

// Query password

$stmt = $conn->prepare("SELECT password FROM Warden WHERE Warden_ID = ?");

$stmt->bind_param("s", $warden_id);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 1) {

  $row = $result->fetch_assoc();

  if ($password === $row['password']) {

    $_SESSION['warden_id'] = $warden_id;

    header("Location: warden_dashboard.php"); // 👉 Your dashboard page

    exit;

  } else {

    $_SESSION['login_error'] = "Incorrect password.";

  }

} else {

  $_SESSION['login_error'] = "Warden ID not found.";

}

header("Location: warden_login.php");

exit;

?>
 