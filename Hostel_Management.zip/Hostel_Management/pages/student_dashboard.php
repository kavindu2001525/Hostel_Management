<?php

session_start();

if (!isset($_SESSION['student_id'])) {

    header("Location: ../login.php");

    exit;

}

$student_id = $_SESSION['student_id'];

// Connect to DB

$conn = new mysqli("localhost", "root", "", "hostel_db");

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}

// Get student name from user table

$name = "";

$stmt = $conn->prepare("SELECT First_Name, Last_Name FROM user WHERE Student_ID = ?");

$stmt->bind_param("s", $student_id);

$stmt->execute();

$stmt->bind_result($first_name, $last_name);

$stmt->fetch();

$stmt->close();

$conn->close();

$name = $first_name . " " . $last_name;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Dashboard</title>
<style>

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {

        font-family: 'Segoe UI', sans-serif;

        background: linear-gradient(-45deg, #a0d8ef, #d0f0fd, #b2ebf2, #e0ffff);

        background-size: 400% 400%;

        animation: gradientMove 15s ease infinite;

        display: flex;

    }

    @keyframes gradientMove {

        0% { background-position: 0% 50%; }

        50% { background-position: 100% 50%; }

        100% { background-position: 0% 50%; }

    }

    .sidebar {

        width: 240px;

        background-color: #007acc;

        height: 100vh;

        padding-top: 30px;

        position: fixed;

        top: 0;

        left: 0;

        color: white;

    }

    .sidebar h2 {

        text-align: center;

        margin-bottom: 30px;

    }

    .sidebar a {

        display: block;

        padding: 15px 25px;

        text-decoration: none;

        color: white;

        transition: 0.3s;

    }

    .sidebar a:hover,

    .sidebar a.active {

        background-color: #005f99;

    }

    .main {

        margin-left: 240px;

        padding: 40px;

        display: flex;

        flex-direction: column;

        gap: 30px;

    }

    .welcome-section {

        background: white;

        padding: 30px;

        border-radius: 10px;

        box-shadow: 0 4px 12px rgba(0,0,0,0.15);

        text-align: center;

    }

    .welcome-section h2 {

        font-size: 26px;

        margin-bottom: 10px;

        color: #007acc;

    }

    .welcome-section p {

        font-size: 16px;

        color: #444;

    }

    .card-container {

        display: flex;

        flex-wrap: wrap;

        justify-content: center;

        gap: 30px;

    }

    .card {

        background: white;

        width: 260px;
        height: 300px;

        border-radius: 10px;

        overflow: hidden;

        box-shadow: 0 6px 12px rgba(0,0,0,0.1);

        text-align: center;

        transition: 0.3s;

    }

    .card:hover {

        transform: scale(1.03);

    }

    .card img {

        width: 100%;

        height: 250px;

        object-fit: cover;

    }

    .card h3 {

        padding: 20px 10px 10px;

        font-size: 18px;

        color: #007acc;

    }

    .card a {

        display: block;

        margin: 0 20px 20px;

        padding: 10px;

        background-color: #007acc;

        color: white;

        text-decoration: none;

        border-radius: 6px;

        transition: 0.3s;

    }

    .card a:hover {

        background-color: #005f99;

    }

    @media (max-width: 768px) {

        .main {

            margin-left: 0;

            padding: 20px;

        }

        .sidebar {

            display: none;

        }
    }
</style>
</head>
<body>
<div class="sidebar">
<h2>Hostel Management System</h2>
<a href="student_dashboard.php" class="active">Home</a>
<a href="profile.php">View Profile</a>
<a href="submit_complaint.php">Submit Complaint</a>
<a href="request_room.php">Room Request</a>
<a href="wardent_approval.php">Warden Approval</a>
<a href="complaint_status.php">Complaint Status</a>
<a href="leave_pass.php">Late Pass</a>
<a href="../logout.php">Logout</a>
</div>
<div class="main">
<div class="welcome-section">
<h2>Welcome, <?php echo htmlspecialchars($name); ?>! 🎉</h2>
<p>Student ID: <?php echo htmlspecialchars($student_id); ?></p>
<p>This is your dashboard. Use the sidebar to access all features.</p>
</div>
<div class="card-container">
<div class="card">
<img src="../images/profile.jpg" alt="Profile">
<a href="profile.php">View Profile</a>
</div>
<div class="card">
<img src="../images/complaint.jpg" alt="Complaint">
<a href="submit_complaint.php">Complaint</a>
</div>
<div class="card">
<img src="../images/roomreq.jpg" alt="Room">
<a href="request_room.php">Room Request</a>
</div>
<div class="card">
<img src="../images/approval.jpg" alt="Room Status">
<a href="room_status.php">Warden Approval</a>
</div>
<div class="card">
<img src="../images/cstatus.jpg" alt="Complaint Status">
<a href="complaint_status.php">Complaint Status</a>
</div>
<div class="card">
<img src="../images/latepass.jpg" alt="Leave">
<a href="late_pass.php">Late Pass</a>
</div>
</div>
</div>
</body>
</html>
 