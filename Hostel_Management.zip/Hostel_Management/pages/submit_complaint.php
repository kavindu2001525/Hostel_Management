<?php

// Show errors for debugging

ini_set('display_errors', 1);

ini_set('display_startup_errors', 1);

error_reporting(E_ALL);

session_start();

// Redirect to login if not logged in

if (!isset($_SESSION['student_id'])) {

    header("Location: ../login.php");

    exit;

}

$student_id = $_SESSION['student_id'];

// Connect to database

$conn = new mysqli("localhost", "root", "", "hostel_db");

// Check connection

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}

$success = "";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $complaint_type = trim($_POST['complaint_type']);

    $description = trim($_POST['description']);

    $date = date('Y-m-d');

    $status = 'Pending';

    if (empty($complaint_type) || empty($description)) {

        $error = "All fields are required.";

    } else {

        $stmt = $conn->prepare("INSERT INTO Complaint (Student_ID, Complaint_Type, Description, Date, Status) VALUES (?, ?, ?, ?, ?)");

        if ($stmt) {

            $stmt->bind_param("sssss", $student_id, $complaint_type, $description, $date, $status);

            if ($stmt->execute()) {

                $success = "✅ Complaint submitted successfully!";

            } else {

                $error = "❌ Failed to submit complaint. Try again.";

            }

            $stmt->close();

        } else {

            $error = "❌ SQL error: " . $conn->error;

        }

    }

}

$conn->close();

?>
<!DOCTYPE html>
<html>
<head>
<title>Submit Complaint</title>
<style>

        body {

            font-family: 'Segoe UI', sans-serif;

            background: #f0f8ff;

            padding: 50px;

        }

        .container {

            max-width: 600px;

            margin: auto;

            background: white;

            padding: 30px;

            border-radius: 10px;

            box-shadow: 0 4px 12px rgba(0,0,0,0.1);

        }

        h2 {

            text-align: center;

            color: #007acc;

        }

        label {

            display: block;

            margin-top: 15px;

            font-weight: bold;

        }

        select, textarea, input[type=submit], .back-btn {

            width: 100%;

            padding: 10px;

            margin-top: 8px;

            border-radius: 6px;

            border: 1px solid #ccc;

            font-size: 16px;

        }

        input[type=submit] {

            background-color: #007acc;

            color: white;

            border: none;

            font-weight: bold;

            cursor: pointer;

            margin-top: 20px;

        }

        input[type=submit]:hover {

            background-color: #005f99;

        }

        .msg {

            text-align: center;

            margin-top: 15px;

            font-weight: bold;

        }

        .success { color: green; }

        .error { color: red; }

        .back-btn {

            background-color: #ccc;

            color: black;

            text-align: center;

            margin-top: 25px;

            text-decoration: none;

            display: block;

        }

        .back-btn:hover {

            background-color: #aaa;

        }
</style>
</head>
<body>
<div class="container">
<h2>Submit a Complaint</h2>
<?php if ($success): ?>
<div class="msg success"><?php echo $success; ?></div>
<?php elseif ($error): ?>
<div class="msg error"><?php echo $error; ?></div>
<?php endif; ?>
<form method="POST" action="">
<label for="complaint_type">Complaint Type</label>
<select name="complaint_type" required>
<option value="">-- Select Type --</option>
<option value="Room Issue">Room Issue</option>
<option value="Food Issue">Food Issue</option>
<option value="Electricity">Electricity</option>
<option value="Water Supply">Water Supply</option>
<option value="Others">Others</option>
</select>
<label for="description">Description</label>
<textarea name="description" rows="5" required></textarea>
<input type="submit" value="Submit Complaint">
</form>
<a href="student_dashboard.php" class="back-btn">← Back</a>
</div>
</body>
</html>
 