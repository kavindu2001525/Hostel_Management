
<?php

error_reporting(E_ALL);

ini_set('display_errors', 1);

// Connect to DB

$host = "localhost";

$user = "root";

$pass = "";

$db   = "hostel_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {

    die("❌ Connection failed: " . $conn->connect_error);

}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $student_id  = $_POST['student_id'] ?? '';

    $first_name  = $_POST['first_name'] ?? '';

    $last_name   = $_POST['last_name'] ?? '';

    $email       = $_POST['email'] ?? '';

    $passwordRaw = $_POST['password'] ?? '';

    if (!$student_id || !$first_name || !$email || !$passwordRaw) {

        die("❌ Please fill all required fields.");

    }

    $hashed_pw = password_hash($passwordRaw, PASSWORD_DEFAULT);

    $sql = "INSERT INTO user (Student_ID, First_Name, Last_Name, Email, password) 

            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {

        die("❌ Prepare failed: " . $conn->error);

    }

    $stmt->bind_param("sssss", $student_id, $first_name, $last_name, $email, $hashed_pw);

    if ($stmt->execute()) {

        echo "
<html>
<head>
<title>Signup Success</title>
<style>

            body {

              font-family: Arial;

              background-color: #e0f9ef;

              display: flex;

              justify-content: center;

              align-items: center;

              height: 100vh;

            }

            .message-box {

              background: white;

              padding: 30px;

              border-radius: 10px;

              text-align: center;

              box-shadow: 0 4px 12px rgba(0,0,0,0.1);

            }

            .message-box a {

              display: inline-block;

              margin-top: 20px;

              padding: 10px 20px;

              background-color: #00b894;

              color: white;

              text-decoration: none;

              border-radius: 5px;

            }

            .message-box a:hover {

              background-color: #019172;

            }
</style>
</head>
<body>
<div class='message-box'>
<h2>✅ Successfully signed up!</h2>
<p>Click below to go back to the Home Page.</p>
<a href='../index.php'>Go to Home</a>
</div>
</body>
</html>";

    } else {

        echo "❌ Error saving user: " . $stmt->error;

    }

    $stmt->close();

} else {

    echo "⚠️ Invalid request.";

}

$conn->close();

?>
 