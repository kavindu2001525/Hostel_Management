<?php

session_start();

if (!isset($_SESSION['warden_id'])) {

  header("Location: warden_login.php");

  exit;

}

?>
<!DOCTYPE html>
<html>
<head><title>Warden Dashboard</title></head>
<body>
<h2>Welcome Warden: <?php echo $_SESSION['warden_id']; ?></h2>
<p>This is your dashboard.</p>
<a href="logout.php">Logout</a>
</body>
</html>
 