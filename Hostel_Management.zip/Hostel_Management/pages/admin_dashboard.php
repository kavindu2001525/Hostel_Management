<?php

session_start();

if (!isset($_SESSION['admin_id'])) {

  header("Location: admin_login.php");

  exit;

}

?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<style>

    body {

      font-family: Arial;

      background: #e6f7ff;

      padding: 40px;

    }

    .dashboard {

      background: white;

      max-width: 600px;

      margin: auto;

      padding: 30px;

      border-radius: 10px;

      box-shadow: 0 4px 12px rgba(0,0,0,0.15);

      text-align: center;

    }

    .dashboard h2 {

      margin-bottom: 20px;

      color: #007acc;

    }

    .dashboard a {

      display: inline-block;

      margin-top: 20px;

      padding: 10px 20px;

      background: #ff4d4d;

      color: white;

      text-decoration: none;

      border-radius: 5px;

    }

    .dashboard a:hover {

      background: #cc0000;

    }
</style>
</head>
<body>
<div class="dashboard">
<h2>Welcome, Admin <?php echo htmlspecialchars($_SESSION['admin_id']); ?>!</h2>
<p>This is your dashboard.</p>
<a href="logout.php">Logout</a>
</div>
</body>
</html>
 