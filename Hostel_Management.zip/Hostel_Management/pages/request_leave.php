<?php

session_start();

if (!isset($_SESSION['student_id'])) {

    header("Location: ../login.php");

    exit;

}

$student_id = $_SESSION['student_id'];

$from = $_POST['from_date'] ?? '';

$to = $_POST['to_date'] ?? '';

$reason = $_POST['reason'] ?? '';

$conn = new mysqli("localhost", "root", "", "hostel_db");

if ($conn->connect_error) {

    die("DB Error: " . $conn->connect_error);

}

if ($from && $to && $reason) {

    $status = "Pending";

    $id = uniqid("L");

    // Make sure table exists

    $conn->query("CREATE TABLE IF NOT EXISTS Leave_Requests (

        Leave_ID VARCHAR(20) PRIMARY KEY,

        Student_ID VARCHAR(10),

        from_date DATE,

        to_date DATE,

        reason TEXT,

        status VARCHAR(20)

    )");

    $stmt = $conn->prepare("INSERT INTO Leave_Requests (Leave_ID, Student_ID, from_date, to_date, reason, status) VALUES (?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("ssssss", $id, $student_id, $from, $to, $reason, $status);

    $stmt->execute();

}

header("Location: student_dashboard.php");

exit;
 