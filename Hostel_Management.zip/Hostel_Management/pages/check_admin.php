<?php

session_start();

// DB connection

$host = "localhost";

$user = "root";

$pass = "";

$db   = "hostel_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {

  die("Connection failed: " . $conn->connect_error);

}

$admin_id = $_POST['admin_id'] ?? '';

$password = $_POST['password'] ?? '';

// Validate

if (empty($admin_id) || empty($password)) {

  $_SESSION['login_error'] = "Please fill both fields.";

  header("Location: admin_login.php");

  exit;

}

// Query DB

$stmt = $conn->prepare("SELECT password FROM Admin WHERE Admin_ID = ?");

$stmt->bind_param("s", $admin_id);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 1) {

  $row = $result->fetch_assoc();

if ($password === $row['password']) {

    // ✅ Login success

    $_SESSION['admin_id'] = $admin_id;

    header("Location: admin_dashboard.php"); // 👉 Redirect to admin dashboard

    exit;

  } else {

    $_SESSION['login_error'] = "Incorrect password.";

  }

} else {

  $_SESSION['login_error'] = "Admin ID not found.";

}

header("Location: admin_login.php");

exit;

?>
 