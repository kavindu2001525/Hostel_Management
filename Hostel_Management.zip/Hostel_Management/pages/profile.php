<?php

session_start();

if (!isset($_SESSION['student_id'])) {

    header("Location: ../login.php");

    exit;

}

$student_id = $_SESSION['student_id'];

$conn = new mysqli("localhost", "root", "", "hostel_db");

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}

// Handle password change

$success = "";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $new_password = $_POST['new_password'];

    $confirm_password = $_POST['confirm_password'];

    if (empty($new_password) || empty($confirm_password)) {

        $error = "Please fill in all password fields.";

    } elseif ($new_password !== $confirm_password) {

        $error = "Passwords do not match.";

    } else {

        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

        $stmt = $conn->prepare("UPDATE user SET password = ? WHERE Student_ID = ?");

        $stmt->bind_param("ss", $hashed_password, $student_id);

        if ($stmt->execute()) {

            $success = "Password updated successfully.";

        } else {

            $error = "Failed to update password.";

        }

        $stmt->close();

    }

}

// Fetch all student data

$stmt = $conn->prepare("SELECT * FROM Student WHERE Student_ID = ?");

$stmt->bind_param("s", $student_id);

$stmt->execute();

$result = $stmt->get_result();

$student = $result->fetch_assoc();

$stmt->close();

$conn->close();

?>
<!DOCTYPE html>
<html>
<head>
<title>Student Profile</title>
<style>

        body {

            font-family: 'Segoe UI', sans-serif;

            background-color: #e6f2ff;

            padding: 40px;

        }

        .container {

            background: white;

            max-width: 700px;

            margin: auto;

            padding: 30px;

            border-radius: 12px;

            box-shadow: 0 4px 12px rgba(0,0,0,0.2);

        }

        h2 {

            text-align: center;

            color: #007acc;

            margin-bottom: 25px;

        }

        .field {

            margin: 10px 0;

            font-size: 16px;

        }

        .field strong {

            display: inline-block;

            width: 160px;

            color: #444;

        }

        form {

            margin-top: 30px;

        }

        label {

            display: block;

            margin-top: 15px;

            font-weight: bold;

        }

        input[type=password] {

            width: 100%;

            padding: 10px;

            border-radius: 6px;

            border: 1px solid #ccc;

        }

        button {

            margin-top: 20px;

            width: 100%;

            padding: 10px;

            background-color: #007acc;

            border: none;

            color: white;

            font-weight: bold;

            border-radius: 6px;

            cursor: pointer;

        }

        .msg {

            text-align: center;

            margin-top: 10px;

            font-weight: bold;

        }

        .msg.success {

            color: green;

        }

        .msg.error {

            color: red;

        }

        .back-button {

            text-align: center;

            margin-top: 30px;

        }

        .back-button a {

            display: inline-block;

            padding: 10px 20px;

            background-color: #007acc;

            color: white;

            text-decoration: none;

            border-radius: 6px;

        }

        .back-button a:hover {

            background-color: #005f99;

        }
</style>
</head>
<body>
<div class="container">
<h2>Your Profile</h2>
<?php if ($student): ?>
<?php foreach ($student as $column => $value): ?>
<?php if (!in_array($column, ['password', 'Admin_ID', 'Warden_ID'])): ?>
<div class="field">
<strong><?php echo htmlspecialchars(str_replace("_", " ", $column)); ?>:</strong>
<?php echo htmlspecialchars($value); ?>
</div>
<?php endif; ?>
<?php endforeach; ?>
<?php else: ?>
<p style="color: red;">Student record not found.</p>
<?php endif; ?>
<form method="POST">
<label for="new_password">New Password</label>
<input type="password" name="new_password" required>
<label for="confirm_password">Confirm Password</label>
<input type="password" name="confirm_password" required>
<button type="submit">Change Password</button>
</form>
<?php if ($success): ?>
<div class="msg success"><?php echo $success; ?></div>
<?php elseif ($error): ?>
<div class="msg error"><?php echo $error; ?></div>
<?php endif; ?>
<div class="back-button">
<a href="student_dashboard.php">← Back</a>
</div>
</div>
</body>
</html>
 