<?php

session_start();

if (!isset($_SESSION['student_id'])) {

    header("Location: ../login.php");

    exit;

}

$student_id = $_SESSION['student_id'];

$conn = new mysqli("localhost", "root", "", "hostel_db");

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}

$sql = "SELECT Complaint_ID, Complaint_Type, Description, Office_Description, Date, Status 

        FROM Complaint 

        WHERE Student_ID = ?";

$stmt = $conn->prepare($sql);

$stmt->bind_param("s", $student_id);

$stmt->execute();

$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html>
<head>
<title>Complaint Status</title>
<style>

        body {

            font-family: 'Segoe UI', sans-serif;

            background: #e6f2ff;

            padding: 30px;

        }

        .container {

            max-width: 900px;

            margin: auto;

            background: white;

            padding: 25px;

            border-radius: 10px;

            box-shadow: 0 4px 10px rgba(0,0,0,0.1);

        }

        h2 {

            text-align: center;

            color: #007acc;

            margin-bottom: 20px;

        }

        table {

            width: 100%;

            border-collapse: collapse;

            margin-top: 15px;

        }

        table th, table td {

            border: 1px solid #ddd;

            padding: 10px;

            text-align: center;

        }

        table th {

            background-color: #007acc;

            color: white;

        }

        .back-btn {

            margin-top: 20px;

            display: block;

            width: 200px;

            text-align: center;

            padding: 10px;

            background-color: #007acc;

            color: white;

            text-decoration: none;

            border-radius: 6px;

            margin-left: auto;

            margin-right: auto;

        }

        .back-btn:hover {

            background-color: #005f99;

        }

        .no-data {

            text-align: center;

            margin-top: 20px;

            color: red;

        }
</style>
</head>
<body>
<div class="container">
<h2>Your Complaint Status</h2>
<?php if ($result->num_rows > 0): ?>
<table>
<tr>
<th>ID</th>
<th>Type</th>
<th>Your Description</th>
<th>Office Response</th>
<th>Date</th>
<th>Status</th>
</tr>
<?php while ($row = $result->fetch_assoc()): ?>
<tr>
<td><?= htmlspecialchars($row['Complaint_ID']) ?></td>
<td><?= htmlspecialchars($row['Complaint_Type']) ?></td>
<td><?= htmlspecialchars($row['Description']) ?></td>
<td><?= htmlspecialchars($row['Office_Description'] ?? '-') ?></td>
<td><?= htmlspecialchars($row['Date']) ?></td>
<td><?= htmlspecialchars($row['Status']) ?></td>
</tr>
<?php endwhile; ?>
</table>
<?php else: ?>
<p class="no-data">You have not submitted any complaints yet.</p>
<?php endif; ?>
<a href="student_dashboard.php" class="back-btn">← Back</a>
</div>
</body>
</html>
 