<?php

session_start();

if (!isset($_SESSION['student_id'])) {

    header("Location: ../login.php");

    exit;

}

$student_id = $_SESSION['student_id'];

$conn = new mysqli("localhost", "root", "", "hostel_db");

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}

$success = "";

$error = "";

// Check if student already requested a room

$check = $conn->prepare("SELECT * FROM Room_Request WHERE Student_ID = ?");

$check->bind_param("s", $student_id);

$check->execute();

$check_result = $check->get_result();

$already_requested = $check_result->num_rows > 0;

// Handle form submission

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['room_number'])) {

    if ($already_requested) {

        $error = "❌ You have already requested a room.";

    } else {

        $room_number = $_POST['room_number'];

        // Insert into Room_Request

        $stmt = $conn->prepare("INSERT INTO Room_Request (Student_ID, Room_Number, Status) VALUES (?, ?, 'Pending')");

        $stmt->bind_param("ss", $student_id, $room_number);

        if ($stmt->execute()) {

            // Update occupied count

            $update = $conn->prepare("UPDATE Room SET Occupied_Count = COALESCE(Occupied_Count, 0) + 1 WHERE Room_Number = ?");

            $update->bind_param("s", $room_number);

            $update->execute();

            $success = "✅ Room requested successfully!";

            $already_requested = true;

        } else {

            $error = "❌ Failed to request room.";

        }

        $stmt->close();

    }

}

?>
<!DOCTYPE html>
<html>
<head>
<title>Room Request</title>
<style>

        body { font-family: Arial; background-color: #f0f8ff; padding: 30px; }

        .container { max-width: 800px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; }

        h2 { text-align: center; color: #007acc; }

        table { width: 100%; border-collapse: collapse; margin-top: 20px; }

        th, td { border: 1px solid #ccc; padding: 12px; text-align: center; }

        th { background-color: #007acc; color: white; }

        .msg { text-align: center; margin-top: 20px; font-weight: bold; }

        .success { color: green; }

        .error { color: red; }

        .back-btn {

            display: block;

            margin-top: 25px;

            text-align: center;

            background-color: #007acc;

            color: black;

            text-decoration: none;

            padding: 10px;

            border-radius: 6px;

        }

        .back-btn:hover { background: #aaa; }
</style>
</head>
<body>
<div class="container">
<h2>Request a Room</h2>
<?php if ($success): ?>
<div class="msg success"><?php echo $success; ?></div>
<?php elseif ($error): ?>
<div class="msg error"><?php echo $error; ?></div>
<?php endif; ?>
<?php if (!$already_requested): ?>
<form method="POST">
<table>
<tr>
<th>Select</th>
<th>Room Number</th>
<th>Type</th>
<th>AC Type</th>
<th>Capacity</th>
<th>Occupied</th>
</tr>
<?php

                $room_query = $conn->query("SELECT * FROM Room WHERE COALESCE(Occupied_Count, 0) < Capacity");

                while ($row = $room_query->fetch_assoc()):

                ?>
<tr>
<td><input type="radio" name="room_number" value="<?php echo $row['Room_Number']; ?>" required></td>
<td><?php echo $row['Room_Number']; ?></td>
<td><?php echo $row['Room_Type']; ?></td>
<td><?php echo $row['AC_Type']; ?></td>
<td><?php echo $row['Capacity']; ?></td>
<td><?php echo $row['Occupied_Count'] ?? 0; ?></td>
</tr>
<?php endwhile; ?>
</table>
<input type="submit" value="Request Room" style="margin-top: 15px; padding: 10px 20px; font-weight: bold;">
</form>
<?php else: ?>
<div class="msg">You have already requested a room.</div>
<?php endif; ?>
<a class="back-btn" href="student_dashboard.php">← Back</a>
</div>
</body>
</html>
 