<!DOCTYPE html>
<html>
<head>
<title>Warden Login</title>
<style>

    body {

      font-family: Arial;

      background-color: #f0f4c3;

      display: flex;

      justify-content: center;

      align-items: center;

      height: 100vh;

    }

    .login-box {

      background: white;

      padding: 30px;

      border-radius: 10px;

      box-shadow: 0 4px 12px rgba(0,0,0,0.2);

      width: 350px;

    }

    h2 {

      text-align: center;

      margin-bottom: 20px;

      color: #689f38;

    }

    input {

      width: 100%;

      padding: 10px;

      margin: 10px 0;

      border-radius: 5px;

      border: 1px solid #ccc;

    }

    button {

      width: 100%;

      padding: 10px;

      background-color: #689f38;

      color: white;

      border: none;

      border-radius: 5px;

    }

    .error {

      color: red;

      text-align: center;

    }
</style>
</head>
<body>
<div class="login-box">
<h2>Warden Login</h2>
<form action="check_warden.php" method="POST">
<input type="text" name="warden_id" placeholder="Warden ID" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Login</button>
</form>
<?php

    session_start();

    if (isset($_SESSION['login_error'])) {

      echo "<p class='error'>" . $_SESSION['login_error'] . "</p>";

      unset($_SESSION['login_error']);

    }

  ?>
</div>
</body>
</html>
 