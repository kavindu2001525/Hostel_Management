<!DOCTYPE html>
<html>
<head>
<title>Student Sign Up</title>
<style>

    body {

      font-family: Arial;

      background-color: #f2faff;

    }

    .signup-box {

      width: 400px;

      margin: 100px auto;

      padding: 30px;

      background: #fff;

      border-radius: 10px;

      box-shadow: 0 4px 12px rgba(0,0,0,0.1);

    }

    .signup-box h2 {

      text-align: center;

      margin-bottom: 20px;

    }

    label {

      display: block;

      margin-bottom: 5px;

      font-weight: bold;

      color: #333;

    }

    input {

      width: 100%;

      padding: 10px;

      margin-bottom: 15px;

      border: 1px solid #ccc;

      border-radius: 5px;

    }

    button {

      padding: 10px 20px;

      background-color: #007acc;

      color: white;

      border: none;

      border-radius: 5px;

      cursor: pointer;

      width: 100%;

    }

    button:hover {

      background-color: #005f99;

    }
</style>
</head>
<body>
<div class="signup-box">
<h2>Student Sign Up</h2>
<form action="save_user.php" method="POST">
<label for="student_id">Student ID</label>
<input type="text" name="student_id" id="student_id" required>
<label for="first_name">First Name</label>
<input type="text" name="first_name" id="first_name" required>
<label for="last_name">Last Name</label>
<input type="text" name="last_name" id="last_name" required>
<label for="email">Email</label>
<input type="email" name="email" id="email" required>
<label for="password">Password</label>
<input type="password" name="password" id="password" required>
<button type="submit">Sign Up</button>
</form>
</div>
</body>
</html>
 