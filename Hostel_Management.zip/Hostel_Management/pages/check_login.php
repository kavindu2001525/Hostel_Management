<?php

session_start();

$host = "localhost";

$user = "root";

$pass = "";

$db   = "hostel_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {

  die("Connection failed: " . $conn->connect_error);

}

$student_id = $_POST['student_id'] ?? '';

$password   = $_POST['password'] ?? '';

if (!$student_id || !$password) {

  $_SESSION['login_error'] = "Please fill both fields.";

  header("Location: login.php");

  exit;

}

// Fetch password from DB

$stmt = $conn->prepare("SELECT password FROM user WHERE Student_ID = ?");

$stmt->bind_param("s", $student_id);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 1) {

  $row = $result->fetch_assoc();

  if (password_verify($password, $row['password'])) {

    // ✅ Password correct - login success

    $_SESSION['student_id'] = $student_id;

    header("Location: student_dashboard.php"); 

    exit;

  } else {

    $_SESSION['login_error'] = "Incorrect password.";

  }

} else {

  $_SESSION['login_error'] = "Student ID not found.";

}

header("Location: login.php");

exit;

?>
 