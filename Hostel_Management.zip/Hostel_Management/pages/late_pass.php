<?php

session_start();

if (!isset($_SESSION['student_id'])) {

    header("Location: ../login.php");

    exit;

}

$student_id = $_SESSION['student_id'];

$conn = new mysqli("localhost", "root", "", "hostel_db");

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}

$success = "";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $visit_date = $_POST['visit_date'];

    $visit_time = $_POST['visit_time'];

    $reason = $_POST['reason'];

    if (empty($visit_date) || empty($visit_time) || empty($reason)) {

        $error = "All fields are required.";

    } else {

        $visitor_id = "V" . rand(1000, 9999); // Generate Visitor_ID

        $stmt = $conn->prepare("INSERT INTO Visitor_Log 

            (Visitor_ID, Student_ID, Visit_Date, Visit_Time, Reason, Warden_Approval_Status) 

            VALUES (?, ?, ?, ?, ?, 'Pending')");

        $stmt->bind_param("sssss", $visitor_id, $student_id, $visit_date, $visit_time, $reason);

        if ($stmt->execute()) {

            $success = "Late pass request submitted successfully.";

        } else {

            $error = "Error submitting request.";

        }

        $stmt->close();

    }

}

$conn->close();

?>
<!DOCTYPE html>
<html>
<head>
<title>Late Pass Request</title>
<style>

        body {

            font-family: Arial;

            background: #e6f2ff;

            padding: 50px;

        }

        .container {

            background: white;

            max-width: 500px;

            margin: auto;

            padding: 25px;

            border-radius: 10px;

            box-shadow: 0 0 10px #999;

        }

        h2 {

            text-align: center;

            color: #007acc;

        }

        label {

            margin-top: 10px;

            display: block;

        }

        input, textarea {

            width: 100%;

            padding: 8px;

            margin-top: 5px;

            margin-bottom: 15px;

        }

        button {

            background-color: #007acc;

            color: white;

            border: none;

            padding: 10px;

            width: 100%;

            border-radius: 5px;

        }

        .msg.success {

            color: green;

            text-align: center;

        }

        .msg.error {

            color: red;

            text-align: center;

        }
</style>
</head>
<body>
<div class="container">
<h2>Request Late Pass</h2>
<?php if ($success): ?>
<p class="msg success"><?php echo $success; ?></p>
<?php elseif ($error): ?>
<p class="msg error"><?php echo $error; ?></p>
<?php endif; ?>
<form method="POST">
<label for="visit_date">Visit Date:</label>
<input type="date" name="visit_date" required>
<label for="visit_time">Visit Time:</label>
<input type="time" name="visit_time" required>
<label for="reason">Reason for Visit:</label>
<textarea name="reason" rows="4" required></textarea>
<button type="submit">Submit Request</button>
</form>
</div>
</body>
</html>
 